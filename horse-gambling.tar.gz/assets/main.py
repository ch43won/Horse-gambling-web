import pygame
import random
import asyncio
from sys import exit #terminate the program

#game variables
GAME_WIDTH = 700
GAME_HEIGHT = 500
FPS = 60

#game mechanics
NUM_HORSES = 4
START_LINE_X = 100
FINISH_LINE_X = 600

START_POINTS = 100

#horse details
HORSE_COLORS = ["red", "blue", "yellow", "purple"]
HORSE_NAMES = ["Red", "Blue", "Yellow", "Purple"]


pygame.init() #always needed to initialize pygame
window = pygame.display.set_mode((GAME_WIDTH, GAME_HEIGHT))
pygame.display.set_caption("Horse Betting Game") #title of the window
clock = pygame.time.Clock() #used for the frame rate
font = pygame.font.SysFont(None, 28) #font and size
big_font = pygame.font.SysFont(None, 40)

points = START_POINTS
bet_amount = 0
selected_horse = None

horses = []
race_active = False
race_finished = False
leaderboard = []

game_over = False

show_instructions = True
menu_rect = pygame.Rect(10, 10, 30, 25)

def reset_race():
    global horses, race_active, race_finished, leaderboard, selected_horse, bet_amount

    horses = []

    lane_height = GAME_HEIGHT // NUM_HORSES
    horse_size = 50

    for i in range(NUM_HORSES):
        y_pos = i * lane_height + (lane_height - horse_size) // 2
        horses.append({
            "rect": pygame.Rect(START_LINE_X - 40, y_pos, horse_size, horse_size),
            "finished": False,
            "place": None,
            "id": i
        })

    race_active = False
    race_finished = False
    leaderboard = []
    selected_horse = None
    bet_amount = 0

def restart_game():
    global points, game_over
    points = START_POINTS
    game_over = False
    reset_race()

def draw_lines():
    pygame.draw.line(window, "white", (START_LINE_X, 0), (START_LINE_X, GAME_HEIGHT), 3)
    pygame.draw.line(window, "white", (FINISH_LINE_X, 0), (FINISH_LINE_X, GAME_HEIGHT), 3)

    start_text = pygame.transform.rotate(font.render("START", True, "white"), 90)
    finish_text = pygame.transform.rotate(font.render("FINISH", True, "white"), 90)

    window.blit(start_text, (START_LINE_X - 30, GAME_HEIGHT // 2 - 50))
    window.blit(finish_text, (FINISH_LINE_X + 10, GAME_HEIGHT // 2 - 50))

def draw_lane_lines():
    lane_height = GAME_HEIGHT // NUM_HORSES

    for i in range(1, NUM_HORSES):
        y = i * lane_height

        for x in range(START_LINE_X, FINISH_LINE_X, 15):
            pygame.draw.line(window, "red", (x, y), (x + 8, y), 2)

def draw_horses():
    for horse in horses:
        rect = horse["rect"]
        color = HORSE_COLORS[horse["id"]]

        x = rect.x
        y = rect.y

        pygame.draw.ellipse(window, color, (x, y + 15, 40, 20))

        pygame.draw.polygon(window, color, [
            (x + 28, y + 24),
            (x + 38, y + 24),
            (x + 42, y + 6),
            (x + 32, y + 6)
        ])

        pygame.draw.circle(window, color, (x + 42, y + 8), 8)

        pygame.draw.ellipse(window, color, (x + 46, y + 7, 10, 6))

        pygame.draw.polygon(window, color, [
            (x + 38, y + 1),
            (x + 41, y - 6),
            (x + 44, y + 1)
        ])

        pygame.draw.line(window, color, (x + 10, y + 33), (x + 10, y + 45), 3)
        pygame.draw.line(window, color, (x + 28, y + 33), (x + 28, y + 45), 3)

        pygame.draw.line(window, color, (x + 2, y + 22), (x - 6, y + 36), 4)

        pygame.draw.circle(window, "black", (x + 44, y + 6), 2)

def move_horses():
    global race_finished

    finished_count = len(leaderboard)

    for horse in horses:
        if not horse["finished"]:
            horse["rect"].x += random.randint(1, 5)

            if horse["rect"].x >= FINISH_LINE_X:
                horse["finished"] = True
                finished_count += 1
                horse["place"] = finished_count
                leaderboard.append(horse)

    if len(leaderboard) == NUM_HORSES:
        race_finished = True

def draw_ui():
    points_text = font.render(f"Points: {points}", True, "black")
    horse_name = HORSE_NAMES[selected_horse] if selected_horse is not None else "None"
    horse_text = font.render(f"Horse: {horse_name}", True, "black")
    bet_text = font.render(f"Bet: {bet_amount}", True, "black")

    spacing = 30
    total_width = points_text.get_width() + horse_text.get_width() + bet_text.get_width() + spacing * 2
    start_x = (GAME_WIDTH - total_width) // 2

    window.blit(points_text, (start_x, 10))
    window.blit(horse_text, (start_x + points_text.get_width() + spacing, 10))
    window.blit(bet_text, (start_x + points_text.get_width() + horse_text.get_width() + spacing * 2, 10))

def draw_leaderboard():
    overlay = pygame.Surface((GAME_WIDTH, GAME_HEIGHT))
    overlay.set_alpha(220)
    overlay.fill("white")
    window.blit(overlay, (0, 0))

    title = big_font.render("Race Results", True, "black")
    window.blit(title, (250, 50))

    for i, horse in enumerate(sorted(leaderboard, key=lambda x: x["place"])):
        name = HORSE_NAMES[horse["id"]]
        text = font.render(f"{i+1}. {name}", True, "black")
        window.blit(text, (280, 120 + i * 40))

    result_text = ""
    if selected_horse is not None:
        winner = sorted(leaderboard, key=lambda x: x["place"])[0]
        if winner["id"] == selected_horse:
            result_text = f"You WON +{bet_amount}!"
        else:
            result_text = f"You LOST -{bet_amount}!"

    result = font.render(result_text, True, "black")
    window.blit(result, (250, 300))

    button_rect = pygame.Rect(250, 350, 200, 50)
    pygame.draw.rect(window, "gray", button_rect)
    text = font.render("Continue", True, "black")
    window.blit(text, (310, 365))

    return button_rect

def draw_game_over():
    window.fill("black")

    text = big_font.render("GAME OVER - You went into debt!", True, "red")
    window.blit(text, (GAME_WIDTH//2 - text.get_width()//2, 180))

    button_rect = pygame.Rect(250, 260, 200, 50)
    pygame.draw.rect(window, "white", button_rect)
    txt = font.render("Restart", True, "black")
    window.blit(txt, (310, 275))

    return button_rect

def draw_menu_button():
    pygame.draw.rect(window, "black", menu_rect, 2)
    for i in range(3):
        pygame.draw.line(window, "black",
                         (menu_rect.x + 5, menu_rect.y + 5 + i * 7),
                         (menu_rect.x + 25, menu_rect.y + 5 + i * 7), 2)

def draw_instructions_overlay():
    overlay = pygame.Surface((GAME_WIDTH, GAME_HEIGHT))
    overlay.set_alpha(128)  
    overlay.fill("black")
    window.blit(overlay, (0, 0))

    lines = [
        "Press 1-4 to pick a horse",
        "Press B to bet (+10 each)",
        "Press ENTER to start",
        "Win = gain bet, Lose = lose bet",
        "Click menu to close"
    ]

    for i, line in enumerate(lines):
        text = font.render(line, True, "white")
        window.blit(text, (GAME_WIDTH//2 - text.get_width()//2, 180 + i * 30))

reset_race()

async def main():
    global game_over,show_instructions,winner,selected_horse,bet_amount,points,race_active,race_finished,restart_button,continue_button
    
    while True: #game loop
        window.fill("#97c480")

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if menu_rect.collidepoint(event.pos):
                    show_instructions = not show_instructions

                if game_over:
                    if restart_button.collidepoint(event.pos):
                        restart_game()

                elif race_finished and not show_instructions:
                    if continue_button.collidepoint(event.pos):
                        winner = sorted(leaderboard, key=lambda x: x["place"])[0]
                        if winner["id"] == selected_horse:
                            points += bet_amount * 2

                        if points <= 0:
                            game_over = True
                        else:
                            reset_race()

            if event.type == pygame.KEYDOWN and not race_active and not race_finished and not show_instructions and not game_over:
                if event.key == pygame.K_1:
                    selected_horse = 0
                if event.key == pygame.K_2:
                    selected_horse = 1
                if event.key == pygame.K_3:
                    selected_horse = 2
                if event.key == pygame.K_4:
                    selected_horse = 3

                if event.key == pygame.K_b:
                    if bet_amount + 10 <= points:
                        bet_amount += 10

                if event.key == pygame.K_RETURN:
                    if selected_horse is not None and bet_amount > 0:
                        race_active = True
                        points -= bet_amount

        draw_lines()
        draw_lane_lines()
        draw_horses()

        if race_active and not show_instructions:
            move_horses()

        if not race_active and not race_finished and not game_over:
            draw_ui()

        if race_finished:
            continue_button = draw_leaderboard()

        if game_over:
            restart_button = draw_game_over()

        draw_menu_button()

        if show_instructions:
            draw_instructions_overlay()
            draw_menu_button()

        pygame.display.update()
        clock.tick(FPS)

        await asyncio.sleep(0)

asyncio.run(main())